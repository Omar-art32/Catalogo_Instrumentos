/*
 * Omar Jim�nez Hern�ndez
 * Paradigmas de programaci�n I
 * 20/06/2024
 * Reto 3
 */
package catalogoinstrumentos;

import catalogoinstrumentos.gui.VentanaPrincipal;

public class MiAplicacionInstrumentos {

	public static void main(String[] args) {
		new VentanaPrincipal();
	}

}
