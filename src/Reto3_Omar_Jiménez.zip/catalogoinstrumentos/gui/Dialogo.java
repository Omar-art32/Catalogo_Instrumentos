/*
 * Omar Jim�nez Hern�ndez
 * Paradigmas de programaci�n I
 * 20/06/2024
 * Reto 3
 */
package catalogoinstrumentos.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

import catalogoinstrumentos.utilerias.MiFocusTraversalPolicy;

public class Dialogo extends JDialog implements ItemListener {
	private static final long serialVersionUID = 1L;
	private VentanaPrincipal ventanaPrincipal;
	private JMenu operacionesMenu;
	private JMenuItem nuevoMenu;
	private JMenuItem modificarMenu;
	private JMenuItem guardarMenu;
	private JMenuItem eliminarMenu;
	private JMenuItem cancelarMenu;
	private JMenuBar barraMenu;

	// Botones de la pantalla
	private JButton nuevoBoton;
	private JButton modificarBoton;
	private JButton guardarBoton;
	private JButton eliminarBoton;
	private JButton cancelarBoton;

	// Botones de mi entidad
	private JTextField a�o;
	private JTextField precio;
	private JTextField nombre;
	private JTextField numeroSerie;
	private JTextField fechaFabricacion; // temporal
	// Condiciones
	private JRadioButton usado; // JRadioButton + ButtonGroup. No editable
	private JRadioButton nuevoRadio;
	private JRadioButton reparado;

	private JComboBox<String> marca; // editable
	// Lista de materiales
	private JList<String> tipoMateriales;
	private JScrollPane scrollPaneMateriales;

	// Lista de g�neros musicales
	private JList<String> generosMusicales;
	private JScrollPane scrollPaneGeneros;

	// Imagen
	private JTextField imagen;
	private JComboBox<String> nombreEntidad;

	// Constructor
	public Dialogo(JFrame principal) {

		super(principal, "Cat�logo de instrumentos");
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/catalogoinstrumentos/imagenes/logo.jpg")));
		ventanaPrincipal = (VentanaPrincipal) principal;
		this.setSize(1200, 600); // Tama�o fijo
		this.setLocationRelativeTo(ventanaPrincipal); // Centrar respecto a ventana principal
		this.setResizable(false); // No redimensionable
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); // El di�logo se destruir� y liberar� sus recursos
		// cuando se cierre.
		this.setModal(true); // Hacer el di�logo modal

		// Creaci�n de acciones
		Action nuevo = new AbstractAction("Nuevo",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/nuevo.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				nuevo();
			}
		};
		nuevo.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
		nuevo.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);
		nuevo.putValue(Action.SHORT_DESCRIPTION, "Nuevo Instrumento");

		Action modificar = new AbstractAction("Modificar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/modificar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				modificar();
			}
		};
		modificar.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_DOWN_MASK));
		modificar.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_M);
		modificar.putValue(Action.SHORT_DESCRIPTION, "Modificar Instrumento");

		Action guardar = new AbstractAction("Guardar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/guardar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				guardar();
			}
		};
		guardar.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK));
		guardar.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_G);
		guardar.putValue(Action.SHORT_DESCRIPTION, "Guardar Cambios");

		Action eliminar = new AbstractAction("Eliminar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/eliminar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				eliminar();
			}
		};

		eliminar.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
		eliminar.putValue(Action.SHORT_DESCRIPTION, "Eliminar Instrumento");

		Action cancelar = new AbstractAction("Cancelar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/cancelar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				cancelar();
			}
		};

		cancelar.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		cancelar.putValue(Action.SHORT_DESCRIPTION, "Cancelar Operaci�n");

		Action agregar = new AbstractAction("Agregar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/agregar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				agregar();
			}
		};
		agregar.putValue(Action.SHORT_DESCRIPTION, "Agregar genero musical");

		Action quitar = new AbstractAction("Quitar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/quitar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				quitar();
			}
		};

		quitar.putValue(Action.SHORT_DESCRIPTION, "Quitar genero musical");

		Action seleccionar = new AbstractAction("Seleccionar",
				new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/seleccionar.png"))) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				seleccionar();
			}
		};
		seleccionar.putValue(Action.SHORT_DESCRIPTION, "Seleccionar imagen");

		// Crear el men�
		barraMenu = new JMenuBar();

		// Men� Operaciones
		operacionesMenu = new JMenu("Operaciones");
		operacionesMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/operaciones.png")));
		operacionesMenu.setMnemonic(KeyEvent.VK_O);

		nuevoMenu = new JMenuItem(nuevo);
		nuevoMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/nuevo.png")));
		nuevoMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
		nuevoMenu.setMnemonic(KeyEvent.VK_N);

		modificarMenu = new JMenuItem(modificar);
		modificarMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/modificar.png")));
		modificarMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_DOWN_MASK));
		modificarMenu.setMnemonic(KeyEvent.VK_M);

		guardarMenu = new JMenuItem(guardar);
		guardarMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/guardar.png")));
		guardarMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK));
		guardarMenu.setMnemonic(KeyEvent.VK_G);

		eliminarMenu = new JMenuItem(eliminar);
		eliminarMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/eliminar.png")));
		eliminarMenu.setMnemonic(KeyEvent.VK_E);

		cancelarMenu = new JMenuItem(cancelar);
		cancelarMenu.setIcon(new ImageIcon(getClass().getResource("/catalogoinstrumentos/imagenes/cancelar.png")));
		cancelarMenu.setMnemonic(KeyEvent.VK_C);

		// A�adir a operaciones
		operacionesMenu.add(nuevoMenu);
		operacionesMenu.add(modificarMenu);
		operacionesMenu.add(guardarMenu);
		operacionesMenu.add(eliminarMenu);
		operacionesMenu.add(cancelarMenu);

		// Agregar men�s a la barra de men�
		barraMenu.add(operacionesMenu);

		// Configurar barra de men�
		this.setJMenuBar(barraMenu);

		// Paneles
		JPanel panelEste = new JPanel();
		JPanel panelOeste = new JPanel();
		JPanel panelNorte = new JPanel();
		JPanel panelCentro = new JPanel();
		JPanel panelAux = new JPanel();

		// Panel Este
		panelEste = new JPanel(new FlowLayout(FlowLayout.RIGHT)); // Panel para los botones en el lado derecho
		panelEste.setPreferredSize(new Dimension(235, 30));

		// BOTONES

		// BOT�N NUEVO

		nuevoBoton = new JButton(nuevo);
		nuevoBoton.getActionMap().put("Nuevo", nuevo);
		nuevoBoton.setIconTextGap(10);

		nuevoBoton.setPreferredSize(new Dimension(150, 30)); // Largo y alto

		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.RIGHT));
		panelAux.add(nuevoBoton);
		panelEste.add(panelAux);

		// Bot�n Modificar

		modificarBoton = new JButton(modificar);
		modificarBoton.getActionMap().put("Modificar", modificar);
		modificarBoton.setIconTextGap(10);

		modificarBoton.setPreferredSize(new Dimension(150, 30));
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.RIGHT));
		panelAux.add(modificarBoton);
		panelEste.add(panelAux);

		// Bot�n Guardar

		guardarBoton = new JButton(guardar);
		guardarBoton.getActionMap().put("Guardar", guardar);
		guardarBoton.setIconTextGap(10);

		guardarBoton.setPreferredSize(new Dimension(150, 30));
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.RIGHT));
		panelAux.add(guardarBoton);
		panelEste.add(panelAux);

		// Bot�n Eliminar

		eliminarBoton = new JButton(eliminar);
		eliminarBoton.getActionMap().put("Eliminar", eliminar);
		eliminarBoton.setIconTextGap(10);

		eliminarBoton.setPreferredSize(new Dimension(150, 30));
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.RIGHT));
		panelAux.add(eliminarBoton);
		panelEste.add(panelAux);

		// Bot�n Cancelar

		cancelarBoton = new JButton(cancelar);
		cancelarBoton.getActionMap().put("Cancelar", cancelar);
		cancelarBoton.setIconTextGap(10);

		cancelarBoton.setPreferredSize(new Dimension(150, 30));
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.RIGHT));
		panelAux.add(cancelarBoton);
		panelEste.add(panelAux);

		// Agregar panelEste al lado Este del BorderLayout
		this.add(panelEste, BorderLayout.EAST);

		// ELEMENTOS DE LA ENTIDAD

		// Panel Norte
		panelNorte.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 20));

		// Entidad
		JLabel nombreEntidadTexto = new JLabel("Entidad");
		nombreEntidadTexto.setDisplayedMnemonic(KeyEvent.VK_E);
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.CENTER));
		panelAux.add(nombreEntidadTexto);
		panelNorte.add(panelAux);

		nombreEntidad = new JComboBox<String>();
		nombreEntidad.addItemListener(this);
		nombreEntidad.setPreferredSize(new Dimension(300, 20));
		panelAux = new JPanel();
		panelAux.setLayout(new FlowLayout(FlowLayout.CENTER));
		panelAux.add(nombreEntidad);
		panelNorte.add(panelAux);

		// Agregar panelNorte al lado arriba del BorderLayout
		this.add(panelNorte, BorderLayout.NORTH);

		// Panel Oeste, usamos GridLayout con 6 filas y 2 columnas
		panelOeste.setLayout(new GridLayout(6, 2));

		// Nombre
		JLabel nombreTexto = new JLabel("Nombre:");
		nombreTexto.setDisplayedMnemonic(KeyEvent.VK_O);
		JPanel panelNombre = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelNombre.add(nombreTexto);
		panelOeste.add(panelNombre);

		nombre = new JTextField("");
		nombre.setPreferredSize(new Dimension(200, 20));
		JPanel panelNombreCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelNombreCampo.add(nombre);
		nombreTexto.setLabelFor(nombre);
		panelOeste.add(panelNombreCampo);

		// Marca
		JLabel marcaTexto = new JLabel("Marca:");
		marcaTexto.setDisplayedMnemonic(KeyEvent.VK_M);
		JPanel panelMarca = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelMarca.add(marcaTexto);
		panelOeste.add(panelMarca);

		marca = new JComboBox<String>();
		marca.setPreferredSize(new Dimension(200, 20));
		JPanel panelMarcaCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelMarcaCampo.add(marca);
		marcaTexto.setLabelFor(marca);
		panelOeste.add(panelMarcaCampo);

		// Condici�n (radios)
		JLabel condicionTexto = new JLabel("Condici�n:");
		condicionTexto.setDisplayedMnemonic(KeyEvent.VK_C);
		JPanel panelCondicion = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		panelCondicion.add(condicionTexto);
		panelOeste.add(panelCondicion);

		ButtonGroup grupoCondiciones = new ButtonGroup();
		usado = new JRadioButton("Usado");
		nuevoRadio = new JRadioButton("Nuevo");
		reparado = new JRadioButton("Reparado");
		grupoCondiciones.add(usado);
		grupoCondiciones.add(nuevoRadio);
		grupoCondiciones.add(reparado);

		JPanel panelRadios = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelRadios.add(usado);
		panelRadios.add(nuevoRadio);
		panelRadios.add(reparado);
		panelOeste.add(panelRadios);

		// A�o
		JLabel a�oTexto = new JLabel("A�o:");
		a�oTexto.setDisplayedMnemonic(KeyEvent.VK_A);
		JPanel panelA�o = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelA�o.add(a�oTexto);
		panelOeste.add(panelA�o);

		a�o = new JTextField("");
		a�o.setPreferredSize(new Dimension(192, 20));
		JPanel panelA�oCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelA�oCampo.add(a�o);
		a�oTexto.setLabelFor(a�o);
		panelOeste.add(panelA�oCampo);

		// Precio
		JLabel precioTexto = new JLabel("Precio:");
		precioTexto.setDisplayedMnemonic(KeyEvent.VK_P);
		JPanel panelPrecio = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelPrecio.add(precioTexto);
		panelOeste.add(panelPrecio);

		precio = new JTextField("");
		precio.setPreferredSize(new Dimension(192, 20));
		JPanel panelPrecioCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelPrecioCampo.add(precio);
		precioTexto.setLabelFor(precio);
		panelOeste.add(panelPrecioCampo);

		// N�mero de serie
		JLabel numeroSerieTexto = new JLabel("N�mero de serie:");
		numeroSerieTexto.setDisplayedMnemonic(KeyEvent.VK_S);
		JPanel panelNumeroSerie = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelNumeroSerie.add(numeroSerieTexto);
		panelOeste.add(panelNumeroSerie);

		numeroSerie = new JTextField("");
		numeroSerie.setPreferredSize(new Dimension(192, 20));
		JPanel panelNumeroSerieCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelNumeroSerieCampo.add(numeroSerie);
		numeroSerieTexto.setLabelFor(numeroSerie);
		panelOeste.add(panelNumeroSerieCampo);

		// Agregar panelOeste al lado izquierdo del BorderLayout
		this.add(panelOeste, BorderLayout.WEST);

		// Crear panelCentro
		panelCentro = new JPanel(new GridLayout(6, 2));

		// Fecha de Fabricaci�n
		JLabel fechaFabricacionTexto = new JLabel("Fecha de fabricaci�n:");
		fechaFabricacionTexto.setDisplayedMnemonic(KeyEvent.VK_F);
		JPanel panelFechaFabricacionEtiqueta = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelFechaFabricacionEtiqueta.add(fechaFabricacionTexto);
		panelCentro.add(panelFechaFabricacionEtiqueta);

		fechaFabricacion = new JTextField("");
		fechaFabricacion.setPreferredSize(new Dimension(192, 20));
		JPanel panelFechaFabricacionCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelFechaFabricacionCampo.add(fechaFabricacion);
		panelCentro.add(panelFechaFabricacionCampo);

		// Tipo Material
		JLabel tipoMaterialTexto = new JLabel("Tipos de Materiales:");
		tipoMaterialTexto.setDisplayedMnemonic(KeyEvent.VK_T);
		JPanel panelTipoMaterialEtiqueta = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelTipoMaterialEtiqueta.add(tipoMaterialTexto);
		panelCentro.add(panelTipoMaterialEtiqueta);

		DefaultListModel<String> modelo2 = new DefaultListModel<>();
		tipoMateriales = new JList<>(modelo2);
		scrollPaneMateriales = new JScrollPane(tipoMateriales);
		scrollPaneMateriales.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPaneMateriales.setPreferredSize(new Dimension(192, 70));
		JPanel panelTipoMaterialCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelTipoMaterialCampo.add(scrollPaneMateriales);
		panelCentro.add(panelTipoMaterialCampo);

		// G�neros Musicales
		JLabel generosMusicalesTexto = new JLabel("G�neros Musicales:");
		generosMusicalesTexto.setDisplayedMnemonic(KeyEvent.VK_G);
		JPanel panelGenerosMusicalesEtiqueta = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelGenerosMusicalesEtiqueta.add(generosMusicalesTexto);
		panelCentro.add(panelGenerosMusicalesEtiqueta);

		DefaultListModel<String> modeloGeneros = new DefaultListModel<>();
		generosMusicales = new JList<>(modeloGeneros);
		scrollPaneGeneros = new JScrollPane(generosMusicales);
		scrollPaneGeneros.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPaneGeneros.setPreferredSize(new Dimension(192, 70));
		JPanel panelGenerosMusicalesCampo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelGenerosMusicalesCampo.add(scrollPaneGeneros);
		panelCentro.add(panelGenerosMusicalesCampo);

		// Botones Agregar y Quitar G�neros Musicales
		JButton botonAgregar = new JButton(agregar);
		JButton botonQuitar = new JButton(quitar);
		JPanel panelBotonesGeneros = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		panelBotonesGeneros.add(botonAgregar);
		panelBotonesGeneros.add(botonQuitar);
		panelCentro.add(new JPanel()); // Panel vac�o para alinear correctamente los componentes
		panelCentro.add(panelBotonesGeneros);

		// Imagen
		JLabel imagenTexto = new JLabel("Imagen:");
		JPanel panelImagenEtiqueta = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelImagenEtiqueta.add(imagenTexto);
		panelCentro.add(panelImagenEtiqueta);
		
		imagen = new JTextField("");
		imagen.setPreferredSize(new Dimension(192, 50));
		panelImagenEtiqueta.add(imagen);
		panelCentro.add(panelImagenEtiqueta);

		// Bot�n Seleccionar Imagen
		JButton botonSeleccionar = new JButton(seleccionar);
		JPanel panelBotonImagen = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 20));
		panelBotonImagen.add(botonSeleccionar);
		panelCentro.add(panelBotonImagen);
		panelCentro.add(new JPanel()); // Panel vac�o para alinear correctamente los componentes

		// Agregar panelCentro al BorderLayout.CENTER
		this.add(panelCentro, BorderLayout.CENTER);

		// Hacer visible el di�logo
		establecerPoliticaFoco();
		this.setVisible(true);

	}

	private void nuevo() {
		JOptionPane.showMessageDialog(null, "Nuevo");
	}

	private void modificar() {
		JOptionPane.showMessageDialog(null, "Modificar");
	}

	private void guardar() {
		JOptionPane.showMessageDialog(null, "Guardar");
	}

	private void eliminar() {
		JOptionPane.showMessageDialog(null, "Eliminar");
	}

	private void cancelar() {
		JOptionPane.showMessageDialog(null, "Cancelar");
	}

	private void seleccionar() {
		JOptionPane.showMessageDialog(null, "Seleccionar");
	}

	private void quitar() {
		JOptionPane.showMessageDialog(null, "Quitar");
	}

	private void agregar() {
		JOptionPane.showMessageDialog(null, "Agregar");
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		// TODO Auto-generated method stub

	}

	private void establecerPoliticaFoco() {
		// Crear el vector de componentes ordenados
		Vector<Component> componentesOrdenados = new Vector<>();

		// Agregar los componentes en el orden l�gico deseado
		componentesOrdenados.add(nuevoBoton);
		componentesOrdenados.add(modificarBoton);
		componentesOrdenados.add(guardarBoton);
		componentesOrdenados.add(eliminarBoton);
		componentesOrdenados.add(cancelarBoton);
		componentesOrdenados.add(nombreEntidad);
		componentesOrdenados.add(nombre);
		componentesOrdenados.add(marca);
		componentesOrdenados.add(usado); // Agregar los radios
		componentesOrdenados.add(nuevoRadio);
		componentesOrdenados.add(reparado);
		componentesOrdenados.add(a�o);
		componentesOrdenados.add(precio);
		componentesOrdenados.add(numeroSerie);
		componentesOrdenados.add(fechaFabricacion);
		componentesOrdenados.add(tipoMateriales);
		componentesOrdenados.add(generosMusicales);

		// Crear la pol�tica de foco con la lista de componentes ordenados
		MiFocusTraversalPolicy politicaFoco = new MiFocusTraversalPolicy(componentesOrdenados);

		// Establecer la pol�tica de foco en el di�logo
		this.setFocusTraversalPolicy(politicaFoco);

	}
}
