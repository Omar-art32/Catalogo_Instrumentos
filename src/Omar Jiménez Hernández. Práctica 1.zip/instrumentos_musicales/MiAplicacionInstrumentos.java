/*
 * Omar Jim�nez Hern�ndez
 * Paradigmas de programaci�n I

 */
package instrumentos_musicales;

import instrumentos_musicales.gui.VentanaPrincipal;

public class MiAplicacionInstrumentos {

	public static void main(String[] args) {
		new VentanaPrincipal();
	}

}
